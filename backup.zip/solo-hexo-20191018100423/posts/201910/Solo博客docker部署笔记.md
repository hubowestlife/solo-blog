title: Solo博客docker部署笔记
date: '2019-10-15 20:44:03'
updated: '2019-10-17 18:18:20'
tags: [待分类]
permalink: /articles/2019/10/15/1571143443076.html
---
![](https://img.hacpai.com/bing/20181203.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


*  安装docker
```
yum install curl -y && curl -fSsL get.docker.com |CHANNEL=stable sh 
systemctl start docker 
systemctl enable docker 
docker version
```
* docker安装mysql
```
# MYSQL_ROOT_PASSWORD=你的数据库密码 
docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=password -d mysql:latest
# docker安装的mysql默认允许远程连接，可以使用Navicat等软件连接数据库 
# 进入容器
mysql docker exec -it mysql bash 
# 进入数据库 p后面跟你的密码 
mysql -uroot -ppassword
# 创建数据库(数据库名:solo;字符集utf8mb4;排序规则utf8mb4_general_ci)
create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;  
#创建成功后退出数据库 ，退出容器  
```
* 安装solo
```
docker run --detach --name solo --network=host \
--env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="root" \
--env JDBC_PASSWORD="password" \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
--rm \
b3log/solo --listen_port=8080 --server_scheme=http --server_host=<ip address>
```
Note：
--listen_port=8080 监听的端口
--server_scheme=http请求方式，暂时使用 http，后面我们会换成 https
--server_host=<IP> 你的域名或者IP，如果你没有域名可以写 IP 地址
--rm因为这个容器后面要删掉，带上 rm 会省很多事

* 安装nginx
```
mkdir -p /solo/nginx/html  
mkdir /solo/nginx/ssl
mkdir /solo/nginx/conf
mkdir /solo/nginx/logs
docker run --name nginx -p 80:80 -d --rm nginx  #启动一个nginx容器
docker cp nginx:/etc/nginx/nginx.conf  /solo/nginx/conf/nginx.conf
docker cp nginx:/etc/nginx/conf.d /solo/nginx/conf/conf.d
docker stop nginx

docker run -d -p 80:80 --name nginx \
-v /solo/nginx/conf/nginx.conf:/etc/nginx/nginx.conf \
-v /solo/nginx/conf/conf.d:/etc/nginx/conf.d \
-v /solo/nginx/www:/usr/share/nginx/html \
-v /solo/nginx/logs:/var/log/nginx nginx
echo "<h1>hello solo blog</h1>" >/solo/nginx/html/index.html
此时就可以在浏览器里面测试了，IP:8080

```
* nginx反向代理
每次要在浏览器里面输入8080端口很麻烦，此时就可以利用nginx反向代理实现访问80端口自动转到8080.
```
vim /solo/nginx/conf.d/default.conf
http的server区域添加：
location / {
        proxy_pass http://IP:8080;  #添加此行，IP填写你具体的IP地址或者域名
    }
docker restart nginx  # 重启nginx使配置生效
```
* Enjoy the show
http://IP
就可以看到你的博客啦，进去进行自定义设置，皮肤等。
---
* Note：
1. 目前以发现的问题：

     如果部署docker部署solo的时候不是用的5.6版本的mysql，你用的是最新的mysql:lastest版本，后面solo有肯能起不来，需要在数据库创建完成再做一步给远程登陆授权和本地授权，不然solo有可能因为授权问题，solo连不上数据库。

