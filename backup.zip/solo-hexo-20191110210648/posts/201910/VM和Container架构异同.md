title: VM 和 Container 架构异同
date: '2019-10-22 15:58:26'
updated: '2019-10-22 15:58:26'
tags: [Docker&VM]
permalink: /articles/2019/10/22/1571731106525.html
---
![image.png](https://img.hacpai.com/file/2019/10/image-1612961f.png)

